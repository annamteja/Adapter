package CovidOhioData;

import com.ddss.interfaces.DataInstance;

public class CovidOhioData implements DataInstance {
	
	private String County;
	private String Sex;
	private String AgeRange;
	private String DateOfDeath;
	private String StateOfDeath;
	private String StateOfResidense;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((AgeRange == null) ? 0 : AgeRange.hashCode());
		result = prime * result + ((County == null) ? 0 : County.hashCode());
		result = prime * result + ((DateOfDeath == null) ? 0 : DateOfDeath.hashCode());
		result = prime * result + ((Sex == null) ? 0 : Sex.hashCode());
		result = prime * result + ((StateOfDeath == null) ? 0 : StateOfDeath.hashCode());
		result = prime * result + ((StateOfResidense == null) ? 0 : StateOfResidense.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CovidOhioData other = (CovidOhioData) obj;
		if (AgeRange == null) {
			if (other.AgeRange != null)
				return false;
		} else if (!AgeRange.equals(other.AgeRange))
			return false;
		if (County == null) {
			if (other.County != null)
				return false;
		} else if (!County.equals(other.County))
			return false;
		if (DateOfDeath == null) {
			if (other.DateOfDeath != null)
				return false;
		} else if (!DateOfDeath.equals(other.DateOfDeath))
			return false;
		if (Sex == null) {
			if (other.Sex != null)
				return false;
		} else if (!Sex.equals(other.Sex))
			return false;
		if (StateOfDeath == null) {
			if (other.StateOfDeath != null)
				return false;
		} else if (!StateOfDeath.equals(other.StateOfDeath))
			return false;
		if (StateOfResidense == null) {
			if (other.StateOfResidense != null)
				return false;
		} else if (!StateOfResidense.equals(other.StateOfResidense))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "CovidOhioData [County=" + County + ", Sex=" + Sex + ", AgeRange=" + AgeRange + ", DateOfDeath="
				+ DateOfDeath + ", StateOfDeath=" + StateOfDeath + ", StateOfResidense=" + StateOfResidense + "]";
	}
	public String getCounty() {
		return County;
	}
	public void setCounty(String county) {
		County = county;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		Sex = sex;
	}
	public String getAgeRange() {
		return AgeRange;
	}
	public void setAgeRange(String ageRange) {
		AgeRange = ageRange;
	}
	public String getDateOfDeath() {
		return DateOfDeath;
	}
	public void setDateOfDeath(String dateOfDeath) {
		DateOfDeath = dateOfDeath;
	}
	public String getStateOfDeath() {
		return StateOfDeath;
	}
	public void setStateOfDeath(String stateOfDeath) {
		StateOfDeath = stateOfDeath;
	}
	public String getStateOfResidense() {
		return StateOfResidense;
	}
	public void setStateOfResidense(String stateOfResidense) {
		StateOfResidense = stateOfResidense;
	}
	public CovidOhioData(String county, String sex, String ageRange, String dateOfDeath, String stateOfDeath,
			String stateOfResidense) {
		
		this.County = county;
		this.Sex = sex;
		this.AgeRange = ageRange;
		this.DateOfDeath = dateOfDeath;
		this.StateOfDeath = stateOfDeath;
		this.StateOfResidense = stateOfResidense;
	}
	

}
