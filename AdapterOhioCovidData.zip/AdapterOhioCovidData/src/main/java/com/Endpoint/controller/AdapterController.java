package com.Endpoint.controller;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ddss.elements.DataArbiter;
import com.ddss.elements.FileHandler;
import com.ddss.elements.Zipping;
@Controller
public class AdapterController 
{
 @PostMapping("/uploadCsv")
public String initialLoginDataScreen() 
{
	
	ApplicationContext appContext = new ClassPathXmlApplicationContext("BeanInjection.xml");
	DataArbiter arbiter = (DataArbiter)appContext.getBean("Arbiter");
	FileHandler handler = (FileHandler)appContext.getBean("FileHandler");
	
	 FileInputStream fis;
	  ResourceBundle resources = null ;
       
            try {
				fis = new FileInputStream("properties.txt");
				   try {
					resources = new PropertyResourceBundle(fis);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
          
            Map<String,String> map = new HashMap<String,String>();

            //convert ResourceBundle to Map
            Enumeration<String> keys = resources.getKeys();
            while (keys.hasMoreElements()) {
                String key = keys.nextElement();
                map.put(key, resources.getString(key));   
                
                
            }
	
          
            
            
	arbiter.setHandler(handler);
	handler.setReceiverInstance(arbiter);
	handler.startHandling();
	
	arbiter.printDelegatingStats();

	
	
return "download";
}

@GetMapping("/adapter")
public String uploadCsvDocument() {
   

    return "uploadDoc";
}


@GetMapping(value = "/zipdownload", produces="application/zip")
public void zipDownload(HttpServletResponse response) throws IOException {
	//Zipping.zippingFiles();
	response.setStatus(HttpServletResponse.SC_OK);
	response.addHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + "splitFilescsv.zip" + "\"");
}
 
}
