package com.ddss.elements;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;



import com.ddss.interfaces.Consumer;
import com.ddss.interfaces.DataInstance;
import com.ddss.interfaces.FileHandlerEssentials;
import com.ddss.interfaces.Distributer;
import com.ddss.interfaces.Receiver;
import com.google.gson.Gson;

import CovidOhioData.CovidOhioData;

public class DataArbiter implements Distributer,Receiver {

	private int availableComputingSystemsCount;
	
	private int totalDataCount;
	private List<Consumer> computingSystemList;
	private FileHandlerEssentials handler;
	
	public DataArbiter(Integer availableComputingSystems) {
		this.availableComputingSystemsCount = availableComputingSystems;
	}
	
	public List<Consumer> getComputingSystemList() {
		return computingSystemList;
	}

	public void setComputingSystemList(List<Consumer> computingSystemList) {
		this.computingSystemList = computingSystemList;
	}


	

	public int getAvailableComputingSystems() {
		return availableComputingSystemsCount;
	}


	
	public int getTotalDataCount() {
		return totalDataCount;
	}


	public int delegateData(CovidOhioData data) {
		int calculatedSystemID=1;
		 FileInputStream fis;
	        try {
	            fis = new FileInputStream("properties.txt");
	            ResourceBundle resources = new PropertyResourceBundle(fis);
	            Map<String,String> map = new HashMap<String,String>();

	            //convert ResourceBundle to Map
	            Enumeration<String> keys = resources.getKeys();
	            while (keys.hasMoreElements()) {
	                String key = keys.nextElement();
	                map.put(key, resources.getString(key));   
	                
	                
	            }
	            //Now you can use the 'map' object as you wish.
	            String countyvalue=map.get(data.getCounty());
	            if(countyvalue!=null)
	      calculatedSystemID=Integer.parseInt(countyvalue.strip());
	           
	           
	        } catch (FileNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }

	
		this.totalDataCount++;	
		 int count=calculatedSystemID ;
		return count;
	}

	@Override
	public void connectWithConsumer(Consumer x) {
		if(this.computingSystemList.size() < this.availableComputingSystemsCount) {
			this.computingSystemList.add(x);
		}
	}

	@Override
	public void disconnectWithConsumer(Consumer x) {
		this.computingSystemList.remove(x);	
	}

	@Override
	public void disconnectAll() {
		this.computingSystemList.clear();
		
	}

	/*
	 * @Override public void dataArrived(DataInstance data) { int
	 * assignedConsumerSystem = this.delegateData(data.hashCode()); Consumer
	 * chosenSystem = this.computingSystemList.get(assignedConsumerSystem);
	 * chosenSystem.update(data);
	 * 
	 * }
	 */
	
	@Override public void dataArrived(CovidOhioData data) {
		int assignedConsumerSystem = this.delegateData(data); 
		Consumer  chosenSystem = this.computingSystemList.get(assignedConsumerSystem);
		 chosenSystem.update(data);
		 
	}

	public FileHandlerEssentials getHandler() {
		return handler;
	}

	public void setHandler(FileHandlerEssentials handler) {
		this.handler = handler;
	}
	@Override
	public void printDelegatingStats() {
		System.out.println("-----------DELEGATING STATS-----------");
		for(Consumer each : this.computingSystemList) {
			System.out.println(each.getName() + " : "+ each.getNumberOfConsumedData());
			ArrayList<CovidOhioData> map=each.getComsumedData();
			String json = new Gson().toJson(map);
			 
			   

			    // move file fron one location to another
			    
			 FileWriter file = null;
			try {
				
				file = new FileWriter( "output"+each.getName()+".json");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	         try {
				file.write(json);
				file.close();
				Path src = Paths.get("output"+each.getName()+".json");
				 Path target = Paths.get("splitFiles/"+"output"+each.getName()+".json");
				Files.move(src, target, StandardCopyOption.REPLACE_EXISTING);
				
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	         
	         
			
		}
		Zipping.zippingFiles();
		System.out.println("-----------TOTAL DATA COUNT-----------");
		System.out.println("Total: "+this.totalDataCount);
	}
}
