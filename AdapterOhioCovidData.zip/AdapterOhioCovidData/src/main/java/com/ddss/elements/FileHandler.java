package com.ddss.elements;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.ddss.interfaces.DataInstance;
import com.ddss.interfaces.FileHandlerEssentials;
import com.ddss.interfaces.Receiver;

import CovidOhioData.CovidOhioData;

public class FileHandler implements FileHandlerEssentials {
	

	private Receiver receiver;
	private CovidOhioData buffer;
	private File inputFile; 

	public FileHandler(String filePath) {
		this.inputFile = new File(filePath);
	}
	
	@Override
	public void notifyReceiver(Receiver receiver) {
		this.receiver.dataArrived(this.buffer);
	}



	@Override
	public void setReceiverInstance(Receiver receiver) {
		this.receiver = receiver;
		
	}



	@Override
	public void startHandling() {
	
		try(Scanner scanner = new Scanner(this.inputFile)){
			StringBuilder collector = new StringBuilder();
			
			while(scanner.hasNextLine()) {
				collector.append(scanner.nextLine());
			}
			JSONParser dataParser = new JSONParser();
			JSONObject totalDataInput = (JSONObject)dataParser.parse(collector.toString());
			
			JSONArray array = (JSONArray)totalDataInput.get("results");
			
			
			
			/*
			 * int CountyIndex=13; int SexIndex=7; int AgeRangeIndex=6; int
			 * DateOfDeathIndex=10; int StateOfDeathIndex=12; int StateOfResidenseIndex=4;
			 */
			for(int each=0; each<array.size(); each++) {
				JSONObject personData = (JSONObject)array.get(each);
			HashMap map=	(HashMap) personData.get("table");
			Set data=personData.entrySet();
			
			String county="";
			String sex="";
			String ageRange="";
			String dateOfDeath="";
			String stateOfDeath="";
			String stateOfResidence="";
		
			
			Iterator persondatatemp=data.iterator();
			while(persondatatemp.hasNext())
			{
				
			Object obj = persondatatemp.next();
			String str = obj.toString();
			String s[] = str.split("=");
			
			if(s[0].equalsIgnoreCase("County"))
			{
				 county =s[1].toString();
			}
			if(s[0].equalsIgnoreCase("Sex"))
			{
				 sex =s[1].toString();
			}
			if(s[0].equalsIgnoreCase("Age Range"))
			{
				 ageRange =s[1].toString();
			}
			if(s[0].equalsIgnoreCase("Date Of Death"))
			{
				 dateOfDeath =s[1].toString();
			}
			if(s[0].equalsIgnoreCase("State of Death"))
			{
				 stateOfDeath =s[1].toString();
			}
			if(s[0].equalsIgnoreCase("State of Residence"))
			{
				 stateOfResidence =s[1].toString();
			}
			
			}
			
			
				
				this.receiver.dataArrived(new CovidOhioData(county,sex,ageRange,dateOfDeath,stateOfDeath,stateOfResidence));
				
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
