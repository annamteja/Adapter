package com.ddss.elements;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext appContext = new ClassPathXmlApplicationContext("BeanInjection.xml");
		DataArbiter arbiter = (DataArbiter)appContext.getBean("Arbiter");
		FileHandler handler = (FileHandler)appContext.getBean("FileHandler");
		
		 FileInputStream fis;
		  ResourceBundle resources = null ;
	       
	            try {
					fis = new FileInputStream("properties.txt");
					   try {
						resources = new PropertyResourceBundle(fis);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	          
	            Map<String,String> map = new HashMap<String,String>();

	            //convert ResourceBundle to Map
	            Enumeration<String> keys = resources.getKeys();
	            while (keys.hasMoreElements()) {
	                String key = keys.nextElement();
	                map.put(key, resources.getString(key));   
	                
	                
	            }
		
	          
	            
	            
		arbiter.setHandler(handler);
		handler.setReceiverInstance(arbiter);
		handler.startHandling();
		
		arbiter.printDelegatingStats();
	}



}
