package com.ddss.elements;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Zipping{

static List<String> totalfiles = new ArrayList<String>();
public static  void zippingFiles() {
try{
File dir = new File("splitFiles");
String dirPath= dir.getAbsolutePath();
Zipping Obj = new Zipping();

Obj.listFiles(dir);

File zipFile = new File("splifiles.zip");

FileOutputStream fos = new FileOutputStream(zipFile);

ZipOutputStream zos = new ZipOutputStream(fos);
byte[] buffer = new byte[1024];
int len;

for (String path : totalfiles) {
File ipfile = new File(path);

String zippath = path.substring(dirPath.length() + 1, path.length());

ZipEntry zen = new ZipEntry(zippath);

zos.putNextEntry(zen);
FileInputStream fis = new FileInputStream(ipfile);
while ((len = fis.read(buffer)) > 0) {
                  zos.write(buffer, 0, len);
                }

zos.closeEntry();
fis.close();
//System.out.println(ipfile.getAbsolutePath()+"is zipped");
}
zos.close();
fos.close();
} catch (IOException e) {
e.printStackTrace();
}
}
public void listFiles(File dir) throws IOException {
File[] files = dir.listFiles();
for (File file : files) {

if (file.isDirectory()) {

listFiles(file);
} else {

totalfiles.add(file.getAbsolutePath());
}
}
}
}