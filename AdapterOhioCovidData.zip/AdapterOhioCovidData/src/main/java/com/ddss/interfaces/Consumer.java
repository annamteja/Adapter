package com.ddss.interfaces;

import java.util.ArrayList;
import java.util.HashMap;

import CovidOhioData.CovidOhioData;

public interface Consumer {

	void update(DataInstance x);
	String getName();
	int getNumberOfConsumedData();
	ArrayList<CovidOhioData> getComsumedData();
}
