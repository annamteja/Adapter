
package com.ddss.interfaces;

public interface DataInstance {

	int hashCode();
	String toString();
}
