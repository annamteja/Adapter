package com.ddss.interfaces;

import CovidOhioData.CovidOhioData;

public interface Receiver {

	void dataArrived(CovidOhioData data);
}
